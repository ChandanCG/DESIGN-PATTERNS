public interface Reader {
			    public void update();
			    //public void add(String name, String[] s);
				public void display(String name);
				public void subscribe(String name,String s);
}

 