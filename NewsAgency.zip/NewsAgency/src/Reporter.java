
public interface Reporter {
	void writeArticle();
	void add(Reader r);

	void notifyEveryone();
}
