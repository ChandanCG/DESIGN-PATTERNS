
public interface Subject {
	  public void register(Reader r);
	  public void unregister(Reader r);
	  public void notifyObserver();
	 
	  	     
}
