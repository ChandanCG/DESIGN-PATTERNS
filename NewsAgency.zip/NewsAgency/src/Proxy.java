
public class Proxy() {
	String oldName;
	String c
	public Proxy(String name,String cat){
		oldname=name;
		c=cat;
	}
	
}
