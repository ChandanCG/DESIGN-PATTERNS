
import java.util.ArrayList;


public class ProxyPremiumReader implements Reader{
	

	static ArrayList<String> ar =new ArrayList<>(); 


	@Override
	public void display(String name) {
		// TODO Auto-generated method stub
		for(int i=0;i<ar.size();i=i+6)
		{
			if(name.equalsIgnoreCase(ar.get(i)))
			{
				int j=i;
				for(int k=0;k<5;k++)
				System.out.println(ar.get(++j)+"\n");
			}
		}
	}

	@Override
	public void subscribe(String name, String[] s) {
		// TODO Auto-generated method stub
		ar.add(name);
		int i;
	for(i=0;i<5;i++)
	{
		if(s[i]==null){
		ar.add(s[i]);break;
		}
	}	
	if(i==5)
		System.out.println("cannot subscribe");
	}
		
//	}

	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}

	//@Override
	//public void subscribe() {
		// TODO Auto-generated method stub
		
	//}

	
}